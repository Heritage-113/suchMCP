#!/usr/bin/env python3
import json, subprocess, sys
exe=sys.argv[1]
proc=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def call(obj):
    proc.stdin.write(json.dumps(obj,separators=(',',':'))+'\n'); proc.stdin.flush()
    line=proc.stdout.readline()
    if not line: raise RuntimeError(proc.stderr.read())
    return json.loads(line)
r=call({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'test','version':'1'}}})
assert r['result']['serverInfo']['name']=='such'
r=call({'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}})
names={x['name'] for x in r['result']['tools']}
assert {'search_files','list_roots','status','set_search_root'} <= names
r=call({'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'search_files','arguments':{'query':'report','max_results':10}}})
assert not r['result']['isError']
assert r['result']['structuredContent']['count']==1
proc.stdin.close(); proc.wait(timeout=5)
print('MCP stdio PASS')
