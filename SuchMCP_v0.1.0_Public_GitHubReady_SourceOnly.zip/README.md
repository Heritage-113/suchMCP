# SuchMCP

Standalone MCP STDIO server for Such local file search.

It is intentionally separate from the Such application repository. Both use the same stable runtime client ABI and dynamically discover the separately distributed search runtime.

## Tools

- `search_files`
- `list_roots`
- `status`
- `add_root`
- `set_search_root` — equivalent to `/drive` / `//drive`
- `remove_root`
- `reindex`
- `set_pin`
- `set_indexed`

See `configs/` for Codex and Claude examples and `scripts/BUILDING.md` for build instructions.
