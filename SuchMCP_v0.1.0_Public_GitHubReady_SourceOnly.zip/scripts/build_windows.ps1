[CmdletBinding()]
param(
 [ValidateSet('Debug','Release','RelWithDebInfo','MinSizeRel')][string]$Config='Release',
 [ValidateSet('x64','Win32','ARM64')][string]$Arch='x64',
 [string]$Generator='Visual Studio 17 2022',
 [ValidateRange(1,64)][int]$Jobs=1,
 [switch]$Clean
)
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
$Root=[System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$Base=if([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)){Join-Path ([IO.Path]::GetTempPath()) 'SuchMCPBuild'}else{Join-Path $env:LOCALAPPDATA 'SuchMCPBuild'}
$Build=Join-Path $Base ("v010-{0}-{1}" -f $Arch.ToLowerInvariant(),$Config.ToLowerInvariant())
if($Clean.IsPresent){Remove-Item -LiteralPath $Build -Recurse -Force -ErrorAction SilentlyContinue}
& cmake -S $Root -B $Build -G $Generator -A $Arch -DSUCH_MCP_STRICT_WARNINGS=ON
if($LASTEXITCODE -ne 0){throw 'configure failed'}
& cmake --build $Build --config $Config --parallel $Jobs
if($LASTEXITCODE -ne 0){throw 'build failed'}
& ctest --test-dir $Build -C $Config --output-on-failure
if($LASTEXITCODE -ne 0){throw 'tests failed'}
Write-Host "SuchMCP build PASS: $Build"
