[CmdletBinding()]
param(
 [ValidateSet('Debug','Release','RelWithDebInfo','MinSizeRel')][string]$Config='Release',
 [ValidateSet('x64','Win32','ARM64')][string]$Arch='x64',
 [switch]$SkipBuild
)
$ErrorActionPreference='Stop'; Set-StrictMode -Version Latest
if(-not$SkipBuild.IsPresent){& (Join-Path $PSScriptRoot 'build_windows.ps1') -Config $Config -Arch $Arch}
$Base=if([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)){throw 'LOCALAPPDATA required'}else{Join-Path $env:LOCALAPPDATA 'SuchMCPBuild'}
$Build=Join-Path $Base ("v010-{0}-{1}" -f $Arch.ToLowerInvariant(),$Config.ToLowerInvariant())
$Exe=Join-Path (Join-Path $Build $Config) 'SuchMCP.exe'; if(-not(Test-Path -LiteralPath $Exe)){throw "missing $Exe"}
$Dest=Join-Path $env:LOCALAPPDATA 'Programs\SuchMCP'; New-Item -ItemType Directory -Force -Path $Dest|Out-Null
Copy-Item -LiteralPath $Exe -Destination (Join-Path $Dest 'SuchMCP.exe') -Force
Write-Host "SuchMCP installed: $Dest"
Write-Host 'Configure your MCP client with the snippets under configs/ and point SUCH_RUNTIME_LIBRARY at the installed Such runtime.'
