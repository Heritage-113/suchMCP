# SuchMCP v0.1.0 Validation

- Linux strict Release build: PASS
- STDIO JSON-RPC initialize: PASS
- tools/list: PASS
- search_files through RuntimeClient test ABI stub: PASS
- Public tree private-backend marker audit: PASS
- Integration against the separately built production runtime: PASS; MCP found the same indexed `project_report.pdf` as SuchCLI.
