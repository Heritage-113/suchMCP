#include <such/mcp/MiniJson.h>
#include <such/runtime/RuntimeClient.h>
#include <such/ui/FrontendLease.h>
#include <such/ui/SearchDialect.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <iostream>
#include <limits>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#if defined(_WIN32)
#include <fcntl.h>
#include <io.h>
#endif

namespace {

using such::mcp::json::Value;
using Object = Value::Object;
using Array = Value::Array;

#if defined(_WIN32)
constexpr auto kDialect = such::ui::PlatformDialect::Windows;
#else
constexpr auto kDialect = such::ui::PlatformDialect::UnixLike;
#endif

constexpr std::string_view kServerName = "such";
constexpr std::string_view kServerVersion = "0.1.0";
constexpr std::string_view kLatestHandshakeProtocol = "2025-11-25";
constexpr std::string_view kInstructions =
    "Such searches the user's local indexed files. Use search_files to locate paths by filename/path plus Such filters. "
    "Search results are metadata and paths, not file contents. Use list_roots/status before changing index state. "
    "add_root, set_search_root, remove_root, reindex, set_pin, and set_indexed mutate Such state; use them only when the user asks.";

Object make_object(std::initializer_list<std::pair<const std::string, Value>> fields) {
    Object out;
    for (const auto& [key, value] : fields) out.insert_or_assign(key, value);
    return out;
}

Value make_text_content(std::string text) {
    return Value(make_object({
        {"type", Value("text")},
        {"text", Value(std::move(text))},
    }));
}

void send_json(const Value& value) {
    std::cout << such::mcp::json::stringify(value) << '\n';
    std::cout.flush();
}

Value id_or_null(const Value& request) {
    if (const auto* id = request.find("id")) return *id;
    return Value(nullptr);
}

void send_result(const Value& request, Value result) {
    send_json(Value(make_object({
        {"jsonrpc", Value("2.0")},
        {"id", id_or_null(request)},
        {"result", std::move(result)},
    })));
}

void send_rpc_error(const Value& request, std::int64_t code, std::string message) {
    send_json(Value(make_object({
        {"jsonrpc", Value("2.0")},
        {"id", id_or_null(request)},
        {"error", Value(make_object({
            {"code", Value(code)},
            {"message", Value(std::move(message))},
        }))},
    })));
}

void send_parse_error(std::string message) {
    send_json(Value(make_object({
        {"jsonrpc", Value("2.0")},
        {"id", Value(nullptr)},
        {"error", Value(make_object({
            {"code", Value(std::int64_t{-32700})},
            {"message", Value(std::move(message))},
        }))},
    })));
}

Value tool_success(std::string text, Value structured = Value(nullptr)) {
    Object result;
    result["content"] = Value(Array{make_text_content(std::move(text))});
    result["isError"] = Value(false);
    if (!structured.is_null()) result["structuredContent"] = std::move(structured);
    return Value(std::move(result));
}

Value tool_error(std::string text) {
    return Value(make_object({
        {"content", Value(Array{make_text_content(std::move(text))})},
        {"isError", Value(true)},
    }));
}

Value empty_schema() {
    return Value(make_object({
        {"type", Value("object")},
        {"properties", Value(Object{})},
        {"additionalProperties", Value(false)},
    }));
}

Value string_property(std::string description) {
    return Value(make_object({
        {"type", Value("string")},
        {"description", Value(std::move(description))},
    }));
}

Value boolean_property(std::string description) {
    return Value(make_object({
        {"type", Value("boolean")},
        {"description", Value(std::move(description))},
    }));
}

Value integer_property(std::string description, std::int64_t minimum, std::int64_t maximum) {
    return Value(make_object({
        {"type", Value("integer")},
        {"minimum", Value(minimum)},
        {"maximum", Value(maximum)},
        {"description", Value(std::move(description))},
    }));
}

Value object_schema(Object properties, Array required = {}) {
    Object schema;
    schema["type"] = Value("object");
    schema["properties"] = Value(std::move(properties));
    schema["additionalProperties"] = Value(false);
    if (!required.empty()) schema["required"] = Value(std::move(required));
    return Value(std::move(schema));
}

Value annotations(bool read_only, bool destructive, bool idempotent) {
    return Value(make_object({
        {"readOnlyHint", Value(read_only)},
        {"destructiveHint", Value(destructive)},
        {"idempotentHint", Value(idempotent)},
        {"openWorldHint", Value(false)},
    }));
}

Value tool_definition(
    std::string name,
    std::string description,
    Value input_schema,
    bool read_only,
    bool destructive = false,
    bool idempotent = true) {
    return Value(make_object({
        {"name", Value(std::move(name))},
        {"description", Value(std::move(description))},
        {"inputSchema", std::move(input_schema)},
        {"annotations", annotations(read_only, destructive, idempotent)},
    }));
}

Value tools_list() {
    Array tools;
    tools.push_back(tool_definition(
        "search_files",
        "Search files already indexed by Such. The query accepts ordinary text plus Such filters such as /pdf, /week, /pin on Windows or //pdf, //week, //pin on Unix-like platforms.",
        object_schema(
            Object{
                {"query", string_property("Such search query. Filters-only queries such as /pdf are allowed; an empty query returns no rows.")},
                {"max_results", integer_property("Maximum results to return. Defaults to 25.", 1, 500)},
            },
            Array{Value("query")}),
        true));
    tools.push_back(tool_definition(
        "list_roots",
        "List directories currently indexed by Such.",
        empty_schema(),
        true));
    tools.push_back(tool_definition(
        "status",
        "Return Such index/runtime status and runtime engine counters.",
        empty_schema(),
        true));
    tools.push_back(tool_definition(
        "add_root",
        "Add a directory to the Such search scope and rebuild the index.",
        object_schema(Object{{"path", string_property("Absolute or local filesystem directory path to index.")}}, Array{Value("path")}),
        false));
    tools.push_back(tool_definition(
        "set_search_root",
        "Replace all current Such search roots with one directory. This is the MCP equivalent of Such /drive (or //drive).",
        object_schema(Object{{"path", string_property("Directory that becomes the complete Such search scope.")}}, Array{Value("path")}),
        false,
        true));
    tools.push_back(tool_definition(
        "remove_root",
        "Remove one directory from the Such search scope and rebuild the index.",
        object_schema(Object{{"path", string_property("Existing indexed root to remove.")}}, Array{Value("path")}),
        false,
        true));
    tools.push_back(tool_definition(
        "reindex",
        "Rebuild the Such local search index for all configured roots.",
        empty_schema(),
        false));
    tools.push_back(tool_definition(
        "set_pin",
        "Pin or unpin an indexed file in Such.",
        object_schema(Object{
            {"path", string_property("Exact indexed file path.")},
            {"pinned", boolean_property("True to pin, false to unpin.")},
        }, Array{Value("path"), Value("pinned")}),
        false));
    tools.push_back(tool_definition(
        "set_indexed",
        "Include or exclude an indexed file from Such search results.",
        object_schema(Object{
            {"path", string_property("Exact indexed file path.")},
            {"indexed", boolean_property("True to include, false to exclude.")},
        }, Array{Value("path"), Value("indexed")}),
        false));
    return Value(make_object({{"tools", Value(std::move(tools))}}));
}

const Value* params_arguments(const Value& request) noexcept {
    const auto* params = request.find("params");
    if (!params || !params->is_object()) return nullptr;
    const auto* arguments = params->find("arguments");
    return arguments && arguments->is_object() ? arguments : nullptr;
}

std::optional<std::string> required_string(const Value* arguments, std::string_view key) {
    if (!arguments) return std::nullopt;
    const auto* value = arguments->find(key);
    if (!value || !value->is_string() || value->as_string().empty()) return std::nullopt;
    return value->as_string();
}

std::optional<bool> required_bool(const Value* arguments, std::string_view key) {
    if (!arguments) return std::nullopt;
    const auto* value = arguments->find(key);
    if (!value || !value->is_bool()) return std::nullopt;
    return value->as_bool();
}

std::size_t max_results_arg(const Value* arguments) {
    constexpr std::size_t kDefault = 25;
    if (!arguments) return kDefault;
    const auto* value = arguments->find("max_results");
    if (!value || !value->is_int()) return kDefault;
    const auto raw = value->as_int();
    if (raw < 1) return 1;
    if (raw > 500) return 500;
    return static_cast<std::size_t>(raw);
}

Value result_item_json(const such::ui::ResultItem& item) {
    return Value(make_object({
        {"file_id", Value(static_cast<std::int64_t>(item.file_id <= static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ? item.file_id : 0u))},
        {"filename", Value(item.filename)},
        {"path", Value(item.path)},
        {"extension", Value(item.extension)},
        {"pinned", Value(item.pinned)},
        {"indexed", Value(item.indexed)},
        {"modified_unix_seconds", Value(item.modified_unix_seconds)},
        {"size_bytes", Value(static_cast<std::int64_t>(item.size_bytes <= static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()) ? item.size_bytes : 0u))},
    }));
}

std::string search_text(const std::vector<such::ui::ResultItem>& results) {
    if (results.empty()) return "No matches.";
    std::string text;
    text.reserve(results.size() * 96u);
    for (const auto& item : results) {
        text += item.filename;
        text += "\t";
        text += item.path;
        if (item.pinned) text += "\tPIN";
        text += "\n";
    }
    if (!text.empty()) text.pop_back();
    return text;
}

Value status_json(const such::runtime::RuntimeClient& runtime) {
    const auto status = runtime.status();
    const auto stats = runtime.engine_stats();
    Array roots;
    roots.reserve(status.roots.size());
    for (const auto& root : status.roots) roots.emplace_back(root);
    return Value(make_object({
        {"indexing", Value(status.indexing)},
        {"indexed_files", Value(static_cast<std::int64_t>(status.indexed_files))},
        {"generation", Value(static_cast<std::int64_t>(status.generation))},
        {"roots", Value(std::move(roots))},
        {"last_error", Value(status.last_error)},
        {"backend_active", Value(stats.backend_active)},
        {"backend_loaded", Value(stats.backend_loaded)},
        {"candidate_rows", Value(static_cast<std::int64_t>(stats.candidate_rows))},
        {"candidate_chunks", Value(static_cast<std::int64_t>(stats.candidate_chunks))},
        {"workers_used", Value(static_cast<std::int64_t>(stats.workers_used))},
        {"parallel", Value(stats.parallel)},
        {"dynamic_queries", Value(static_cast<std::int64_t>(stats.dynamic_queries))},
        {"dynamic_tiles", Value(static_cast<std::int64_t>(stats.dynamic_tiles))},
        {"direct_compaction_queries", Value(static_cast<std::int64_t>(stats.direct_compaction_queries))},
    }));
}

Value handle_tool_call(const Value& request, such::runtime::RuntimeClient& runtime) {
    const auto* params = request.find("params");
    if (!params || !params->is_object()) return tool_error("tools/call requires object params.");
    const auto* name_value = params->find("name");
    if (!name_value || !name_value->is_string()) return tool_error("tools/call requires a tool name.");
    const std::string& name = name_value->as_string();
    const Value* arguments = params_arguments(request);
    std::string error;

    if (name == "search_files") {
        std::string query;
        if (arguments) {
            if (const auto* value = arguments->find("query")) {
                if (!value->is_string()) return tool_error("search_files.query must be a string.");
                query = value->as_string();
            }
        }
        const auto max_results = max_results_arg(arguments);
        const auto results = runtime.search(query, kDialect, max_results);
        Array rows;
        rows.reserve(results.size());
        for (const auto& item : results) rows.push_back(result_item_json(item));
        Value structured(make_object({
            {"query", Value(query)},
            {"count", Value(static_cast<std::int64_t>(results.size()))},
            {"results", Value(std::move(rows))},
        }));
        return tool_success(search_text(results), std::move(structured));
    }

    if (name == "list_roots") {
        const auto roots = runtime.roots();
        Array rows;
        rows.reserve(roots.size());
        std::string text;
        for (const auto& root : roots) {
            rows.emplace_back(root);
            if (!text.empty()) text.push_back('\n');
            text += root;
        }
        if (roots.empty()) text = "No indexed roots.";
        return tool_success(std::move(text), Value(make_object({{"roots", Value(std::move(rows))}})));
    }

    if (name == "status") {
        const Value structured = status_json(runtime);
        const auto status = runtime.status();
        std::string text = "indexed_files=" + std::to_string(status.indexed_files) +
            " indexing=" + std::string(status.indexing ? "true" : "false") +
            " roots=" + std::to_string(status.roots.size());
        if (!status.last_error.empty()) text += " last_error=" + status.last_error;
        return tool_success(std::move(text), structured);
    }

    if (name == "add_root") {
        const auto path = required_string(arguments, "path");
        if (!path) return tool_error("add_root.path is required.");
        if (!runtime.add_root(std::filesystem::path(*path), &error)) return tool_error("add_root failed: " + error);
        runtime.wait_for_idle();
        return tool_success("Indexed root added: " + *path, status_json(runtime));
    }

    if (name == "set_search_root") {
        const auto path = required_string(arguments, "path");
        if (!path) return tool_error("set_search_root.path is required.");
        if (!runtime.replace_roots({std::filesystem::path(*path)}, &error)) return tool_error("set_search_root failed: " + error);
        runtime.wait_for_idle();
        return tool_success("Search root replaced with: " + *path, status_json(runtime));
    }

    if (name == "remove_root") {
        const auto path = required_string(arguments, "path");
        if (!path) return tool_error("remove_root.path is required.");
        if (!runtime.remove_root(std::filesystem::path(*path), &error)) return tool_error("remove_root failed: " + error);
        runtime.wait_for_idle();
        return tool_success("Indexed root removed: " + *path, status_json(runtime));
    }

    if (name == "reindex") {
        runtime.reindex_async();
        runtime.wait_for_idle();
        return tool_success("Reindex complete.", status_json(runtime));
    }

    if (name == "set_pin") {
        const auto path = required_string(arguments, "path");
        const auto pinned = required_bool(arguments, "pinned");
        if (!path || !pinned.has_value()) return tool_error("set_pin requires string path and boolean pinned.");
        if (!runtime.set_pinned(*path, *pinned, &error)) return tool_error("set_pin failed: " + error);
        return tool_success(std::string(*pinned ? "Pinned: " : "Unpinned: ") + *path);
    }

    if (name == "set_indexed") {
        const auto path = required_string(arguments, "path");
        const auto indexed = required_bool(arguments, "indexed");
        if (!path || !indexed.has_value()) return tool_error("set_indexed requires string path and boolean indexed.");
        if (!runtime.set_indexed(*path, *indexed, &error)) return tool_error("set_indexed failed: " + error);
        return tool_success(std::string(*indexed ? "Included in search: " : "Excluded from search: ") + *path);
    }

    return tool_error("Unknown Such MCP tool: " + name);
}

std::string negotiated_protocol(const Value& request) {
    const auto* params = request.find("params");
    if (!params || !params->is_object()) return std::string(kLatestHandshakeProtocol);
    const auto* version = params->find("protocolVersion");
    if (!version || !version->is_string()) return std::string(kLatestHandshakeProtocol);
    const std::string& requested = version->as_string();
    static constexpr std::string_view supported[] = {
        "2025-11-25",
        "2025-06-18",
        "2025-03-26",
        "2024-11-05",
    };
    for (const auto candidate : supported) {
        if (requested == candidate) return requested;
    }
    return std::string(kLatestHandshakeProtocol);
}

void handle_request(const Value& request, such::runtime::RuntimeClient& runtime) {
    if (!request.is_object()) {
        send_rpc_error(request, -32600, "Invalid Request");
        return;
    }
    const auto* jsonrpc = request.find("jsonrpc");
    const auto* method_value = request.find("method");
    if (!jsonrpc || !jsonrpc->is_string() || jsonrpc->as_string() != "2.0" || !method_value || !method_value->is_string()) {
        if (request.find("id")) send_rpc_error(request, -32600, "Invalid Request");
        return;
    }
    const std::string& method = method_value->as_string();
    const bool notification = request.find("id") == nullptr;

    if (method == "notifications/initialized" || method == "notifications/cancelled") return;
    if (notification) return;

    if (method == "initialize") {
        send_result(request, Value(make_object({
            {"protocolVersion", Value(negotiated_protocol(request))},
            {"capabilities", Value(make_object({
                {"tools", Value(make_object({{"listChanged", Value(false)}}))},
            }))},
            {"serverInfo", Value(make_object({
                {"name", Value(std::string(kServerName))},
                {"version", Value(std::string(kServerVersion))},
                {"title", Value("Such Local Search")},
            }))},
            {"instructions", Value(std::string(kInstructions))},
        })));
        return;
    }
    if (method == "ping") {
        send_result(request, Value(Object{}));
        return;
    }
    if (method == "tools/list") {
        send_result(request, tools_list());
        return;
    }
    if (method == "tools/call") {
        send_result(request, handle_tool_call(request, runtime));
        return;
    }
    send_rpc_error(request, -32601, "Method not found: " + method);
}

} // namespace

int main() {
#if defined(_WIN32)
    // Prevent CRT text translation from changing newline-delimited UTF-8 JSON bytes.
    _setmode(_fileno(stdin), _O_BINARY);
    _setmode(_fileno(stdout), _O_BINARY);
#endif

    auto lease = such::ui::FrontendLease::try_acquire(such::ui::FrontendMode::Mcp);
    if (!lease.acquired()) {
        std::fprintf(stderr, "Such MCP could not acquire the local index lease: %s\n", lease.error().c_str());
        return 23;
    }

    such::runtime::RuntimeClient runtime;
    std::string error;
    if (!runtime.load(&error)) {
        std::fprintf(stderr, "Such MCP index load failed: %s\n", error.c_str());
        return 5;
    }

    std::string line;
    while (std::getline(std::cin, line)) {
        if (line.empty()) continue;
        const auto parsed = such::mcp::json::parse(line);
        if (!parsed.value.has_value()) {
            send_parse_error(parsed.error.empty() ? "Parse error" : parsed.error);
            continue;
        }
        try {
            handle_request(*parsed.value, runtime);
        } catch (const std::exception& e) {
            send_rpc_error(*parsed.value, -32603, std::string("Internal error: ") + e.what());
        } catch (...) {
            send_rpc_error(*parsed.value, -32603, "Internal error");
        }
    }
    return 0;
}
