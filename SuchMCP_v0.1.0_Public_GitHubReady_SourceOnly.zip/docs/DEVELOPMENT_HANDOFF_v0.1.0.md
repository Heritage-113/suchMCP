# SuchMCP v0.1.0 Handoff

SuchMCP is a separate public repository from Such.

It contains:
- MCP STDIO JSON-RPC server
- stable runtime ABI/client
- Codex and Claude configuration examples
- no production search/storage implementation

The server exposes search, root management, reindex, pin, and indexed-state tools. `set_search_root` is the MCP equivalent of `/drive` / `//drive`.
