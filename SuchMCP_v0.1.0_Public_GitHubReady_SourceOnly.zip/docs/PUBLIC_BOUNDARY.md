# Public boundary

SuchMCP contains protocol glue and the stable runtime client only. Search/storage implementation code and third-party backend sources are physically outside this repository.
