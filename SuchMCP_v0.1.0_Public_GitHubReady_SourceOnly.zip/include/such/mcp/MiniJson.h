#pragma once

#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace such::mcp::json {

class Value final {
public:
    using Array = std::vector<Value>;
    using Object = std::map<std::string, Value, std::less<>>;
    enum class Type : std::uint8_t { Null, Boolean, Integer, Number, String, Array, Object };

    Value() noexcept = default;
    Value(std::nullptr_t) noexcept {}
    Value(bool value) noexcept : type_(Type::Boolean), bool_value_(value) {}
    Value(std::int64_t value) noexcept : type_(Type::Integer), int_value_(value) {}
    Value(double value) noexcept : type_(Type::Number), double_value_(value) {}
    Value(std::string value) : type_(Type::String), string_value_(std::move(value)) {}
    Value(const char* value) : type_(Type::String), string_value_(value ? value : "") {}
    Value(Array value) : type_(Type::Array), array_value_(std::move(value)) {}
    Value(Object value) : type_(Type::Object), object_value_(std::move(value)) {}

    [[nodiscard]] Type type() const noexcept { return type_; }
    [[nodiscard]] bool is_null() const noexcept { return type_ == Type::Null; }
    [[nodiscard]] bool is_bool() const noexcept { return type_ == Type::Boolean; }
    [[nodiscard]] bool is_int() const noexcept { return type_ == Type::Integer; }
    [[nodiscard]] bool is_double() const noexcept { return type_ == Type::Number; }
    [[nodiscard]] bool is_number() const noexcept { return is_int() || is_double(); }
    [[nodiscard]] bool is_string() const noexcept { return type_ == Type::String; }
    [[nodiscard]] bool is_array() const noexcept { return type_ == Type::Array; }
    [[nodiscard]] bool is_object() const noexcept { return type_ == Type::Object; }

    [[nodiscard]] bool as_bool(bool fallback = false) const noexcept;
    [[nodiscard]] std::int64_t as_int(std::int64_t fallback = 0) const noexcept;
    [[nodiscard]] double as_double(double fallback = 0.0) const noexcept;
    [[nodiscard]] const std::string& as_string() const noexcept;
    [[nodiscard]] const Array& as_array() const noexcept;
    [[nodiscard]] const Object& as_object() const noexcept;
    [[nodiscard]] Array& as_array();
    [[nodiscard]] Object& as_object();

    [[nodiscard]] const Value* find(std::string_view key) const noexcept;
    [[nodiscard]] Value* find(std::string_view key) noexcept;

private:
    Type type_ = Type::Null;
    bool bool_value_ = false;
    std::int64_t int_value_ = 0;
    double double_value_ = 0.0;
    std::string string_value_;
    Array array_value_;
    Object object_value_;
};

struct ParseResult {
    std::optional<Value> value;
    std::string error;
};

[[nodiscard]] ParseResult parse(std::string_view text);
[[nodiscard]] std::string stringify(const Value& value);

} // namespace such::mcp::json
