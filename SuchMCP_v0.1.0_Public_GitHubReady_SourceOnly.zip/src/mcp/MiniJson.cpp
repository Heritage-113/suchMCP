#include <such/mcp/MiniJson.h>

#include <charconv>
#include <cmath>
#include <cstdlib>
#include <cstddef>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace such::mcp::json {
namespace {

const std::string kEmptyString;
const Value::Array kEmptyArray;
const Value::Object kEmptyObject;

void append_utf8(std::string& out, std::uint32_t cp) {
    if (cp <= 0x7Fu) {
        out.push_back(static_cast<char>(cp));
    } else if (cp <= 0x7FFu) {
        out.push_back(static_cast<char>(0xC0u | (cp >> 6u)));
        out.push_back(static_cast<char>(0x80u | (cp & 0x3Fu)));
    } else if (cp <= 0xFFFFu) {
        out.push_back(static_cast<char>(0xE0u | (cp >> 12u)));
        out.push_back(static_cast<char>(0x80u | ((cp >> 6u) & 0x3Fu)));
        out.push_back(static_cast<char>(0x80u | (cp & 0x3Fu)));
    } else {
        out.push_back(static_cast<char>(0xF0u | (cp >> 18u)));
        out.push_back(static_cast<char>(0x80u | ((cp >> 12u) & 0x3Fu)));
        out.push_back(static_cast<char>(0x80u | ((cp >> 6u) & 0x3Fu)));
        out.push_back(static_cast<char>(0x80u | (cp & 0x3Fu)));
    }
}

int hex_digit(char c) noexcept {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

class Parser final {
public:
    explicit Parser(std::string_view text) : text_(text) {}

    ParseResult run() {
        skip_ws();
        auto value = parse_value();
        if (!value.has_value()) return {std::nullopt, error_};
        skip_ws();
        if (pos_ != text_.size()) return {std::nullopt, "trailing characters after JSON value"};
        return {std::move(value), {}};
    }

private:
    std::optional<Value> parse_value() {
        if (pos_ >= text_.size()) return fail("unexpected end of JSON");
        const char c = text_[pos_];
        if (c == '{') return parse_object();
        if (c == '[') return parse_array();
        if (c == '"') {
            auto value = parse_string();
            if (!value.has_value()) return std::nullopt;
            return Value(std::move(*value));
        }
        if (c == 't') return parse_literal("true", Value(true));
        if (c == 'f') return parse_literal("false", Value(false));
        if (c == 'n') return parse_literal("null", Value(nullptr));
        if (c == '-' || (c >= '0' && c <= '9')) return parse_number();
        return fail("unexpected character in JSON");
    }

    std::optional<Value> parse_object() {
        ++pos_;
        skip_ws();
        Value::Object object;
        if (consume('}')) return Value(std::move(object));
        while (pos_ < text_.size()) {
            if (text_[pos_] != '"') return fail("object key must be a string");
            auto key = parse_string();
            if (!key.has_value()) return std::nullopt;
            skip_ws();
            if (!consume(':')) return fail("expected ':' after object key");
            skip_ws();
            auto value = parse_value();
            if (!value.has_value()) return std::nullopt;
            object.insert_or_assign(std::move(*key), std::move(*value));
            skip_ws();
            if (consume('}')) return Value(std::move(object));
            if (!consume(',')) return fail("expected ',' or '}' in object");
            skip_ws();
        }
        return fail("unterminated object");
    }

    std::optional<Value> parse_array() {
        ++pos_;
        skip_ws();
        Value::Array array;
        if (consume(']')) return Value(std::move(array));
        while (pos_ < text_.size()) {
            auto value = parse_value();
            if (!value.has_value()) return std::nullopt;
            array.push_back(std::move(*value));
            skip_ws();
            if (consume(']')) return Value(std::move(array));
            if (!consume(',')) return fail("expected ',' or ']' in array");
            skip_ws();
        }
        return fail("unterminated array");
    }

    std::optional<std::string> parse_string() {
        if (!consume('"')) {
            fail("expected string");
            return std::nullopt;
        }
        std::string out;
        while (pos_ < text_.size()) {
            const unsigned char uc = static_cast<unsigned char>(text_[pos_++]);
            if (uc == '"') return out;
            if (uc < 0x20u) {
                fail("control character in JSON string");
                return std::nullopt;
            }
            if (uc != '\\') {
                out.push_back(static_cast<char>(uc));
                continue;
            }
            if (pos_ >= text_.size()) {
                fail("unterminated JSON escape");
                return std::nullopt;
            }
            const char esc = text_[pos_++];
            switch (esc) {
                case '"': out.push_back('"'); break;
                case '\\': out.push_back('\\'); break;
                case '/': out.push_back('/'); break;
                case 'b': out.push_back('\b'); break;
                case 'f': out.push_back('\f'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    auto cp = parse_hex4();
                    if (!cp.has_value()) return std::nullopt;
                    std::uint32_t codepoint = *cp;
                    if (codepoint >= 0xD800u && codepoint <= 0xDBFFu) {
                        if (pos_ + 2u > text_.size() || text_[pos_] != '\\' || text_[pos_ + 1u] != 'u') {
                            fail("high surrogate without low surrogate");
                            return std::nullopt;
                        }
                        pos_ += 2u;
                        auto low = parse_hex4();
                        if (!low.has_value() || *low < 0xDC00u || *low > 0xDFFFu) {
                            fail("invalid low surrogate");
                            return std::nullopt;
                        }
                        codepoint = 0x10000u + ((codepoint - 0xD800u) << 10u) + (*low - 0xDC00u);
                    } else if (codepoint >= 0xDC00u && codepoint <= 0xDFFFu) {
                        fail("unexpected low surrogate");
                        return std::nullopt;
                    }
                    append_utf8(out, codepoint);
                    break;
                }
                default:
                    fail("invalid JSON escape");
                    return std::nullopt;
            }
        }
        fail("unterminated JSON string");
        return std::nullopt;
    }

    std::optional<std::uint32_t> parse_hex4() {
        if (pos_ + 4u > text_.size()) {
            fail("short unicode escape");
            return std::nullopt;
        }
        std::uint32_t value = 0;
        for (int i = 0; i < 4; ++i) {
            const int digit = hex_digit(text_[pos_++]);
            if (digit < 0) {
                fail("invalid unicode escape");
                return std::nullopt;
            }
            value = (value << 4u) | static_cast<std::uint32_t>(digit);
        }
        return value;
    }

    std::optional<Value> parse_number() {
        const std::size_t start = pos_;
        if (text_[pos_] == '-') ++pos_;
        if (pos_ >= text_.size()) return fail("invalid number");
        if (text_[pos_] == '0') {
            ++pos_;
        } else if (text_[pos_] >= '1' && text_[pos_] <= '9') {
            while (pos_ < text_.size() && text_[pos_] >= '0' && text_[pos_] <= '9') ++pos_;
        } else {
            return fail("invalid number");
        }
        bool floating = false;
        if (pos_ < text_.size() && text_[pos_] == '.') {
            floating = true;
            ++pos_;
            const std::size_t fraction_start = pos_;
            while (pos_ < text_.size() && text_[pos_] >= '0' && text_[pos_] <= '9') ++pos_;
            if (pos_ == fraction_start) return fail("invalid number fraction");
        }
        if (pos_ < text_.size() && (text_[pos_] == 'e' || text_[pos_] == 'E')) {
            floating = true;
            ++pos_;
            if (pos_ < text_.size() && (text_[pos_] == '+' || text_[pos_] == '-')) ++pos_;
            const std::size_t exponent_start = pos_;
            while (pos_ < text_.size() && text_[pos_] >= '0' && text_[pos_] <= '9') ++pos_;
            if (pos_ == exponent_start) return fail("invalid number exponent");
        }
        const std::string_view token = text_.substr(start, pos_ - start);
        if (!floating) {
            std::int64_t integer = 0;
            const auto parsed = std::from_chars(token.data(), token.data() + token.size(), integer);
            if (parsed.ec == std::errc{} && parsed.ptr == token.data() + token.size()) return Value(integer);
        }
        std::string owned(token);
        char* end = nullptr;
        const double d = std::strtod(owned.c_str(), &end);
        if (end == owned.c_str() + owned.size() && std::isfinite(d)) return Value(d);
        return fail("invalid JSON number");
    }

    std::optional<Value> parse_literal(std::string_view literal, Value value) {
        if (text_.substr(pos_, literal.size()) != literal) return fail("invalid JSON literal");
        pos_ += literal.size();
        return value;
    }

    std::optional<Value> fail(std::string message) {
        if (error_.empty()) {
            error_ = std::move(message) + " at byte " + std::to_string(pos_);
        }
        return std::nullopt;
    }

    bool consume(char c) noexcept {
        if (pos_ < text_.size() && text_[pos_] == c) {
            ++pos_;
            return true;
        }
        return false;
    }

    void skip_ws() noexcept {
        while (pos_ < text_.size()) {
            const char c = text_[pos_];
            if (c == ' ' || c == '\t' || c == '\r' || c == '\n') ++pos_;
            else break;
        }
    }

    std::string_view text_;
    std::size_t pos_ = 0;
    std::string error_;
};

void escape_string(std::string& out, std::string_view value) {
    static constexpr char hex[] = "0123456789abcdef";
    out.push_back('"');
    for (const char raw : value) {
        const auto c = static_cast<unsigned char>(raw);
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20u) {
                    out += "\\u00";
                    out.push_back(hex[(c >> 4u) & 0x0Fu]);
                    out.push_back(hex[c & 0x0Fu]);
                } else {
                    out.push_back(static_cast<char>(c));
                }
                break;
        }
    }
    out.push_back('"');
}

void stringify_into(std::string& out, const Value& value) {
    if (value.is_null()) {
        out += "null";
    } else if (value.is_bool()) {
        out += value.as_bool() ? "true" : "false";
    } else if (value.is_int()) {
        out += std::to_string(value.as_int());
    } else if (value.is_double()) {
        std::ostringstream stream;
        stream.precision(std::numeric_limits<double>::max_digits10);
        stream << value.as_double();
        out += stream.str();
    } else if (value.is_string()) {
        escape_string(out, value.as_string());
    } else if (value.is_array()) {
        out.push_back('[');
        bool first = true;
        for (const auto& item : value.as_array()) {
            if (!first) out.push_back(',');
            first = false;
            stringify_into(out, item);
        }
        out.push_back(']');
    } else if (value.is_object()) {
        out.push_back('{');
        bool first = true;
        for (const auto& [key, item] : value.as_object()) {
            if (!first) out.push_back(',');
            first = false;
            escape_string(out, key);
            out.push_back(':');
            stringify_into(out, item);
        }
        out.push_back('}');
    }
}

} // namespace

bool Value::as_bool(bool fallback) const noexcept {
    return is_bool() ? bool_value_ : fallback;
}

std::int64_t Value::as_int(std::int64_t fallback) const noexcept {
    return is_int() ? int_value_ : fallback;
}

double Value::as_double(double fallback) const noexcept {
    if (is_double()) return double_value_;
    if (is_int()) return static_cast<double>(int_value_);
    return fallback;
}

const std::string& Value::as_string() const noexcept {
    return is_string() ? string_value_ : kEmptyString;
}

const Value::Array& Value::as_array() const noexcept {
    return is_array() ? array_value_ : kEmptyArray;
}

const Value::Object& Value::as_object() const noexcept {
    return is_object() ? object_value_ : kEmptyObject;
}

Value::Array& Value::as_array() {
    if (!is_array()) {
        type_ = Type::Array;
        array_value_.clear();
    }
    return array_value_;
}

Value::Object& Value::as_object() {
    if (!is_object()) {
        type_ = Type::Object;
        object_value_.clear();
    }
    return object_value_;
}

const Value* Value::find(std::string_view key) const noexcept {
    if (!is_object()) return nullptr;
    const auto it = object_value_.find(key);
    return it == object_value_.end() ? nullptr : &it->second;
}

Value* Value::find(std::string_view key) noexcept {
    if (!is_object()) return nullptr;
    const auto it = object_value_.find(key);
    return it == object_value_.end() ? nullptr : &it->second;
}

ParseResult parse(std::string_view text) {
    return Parser(text).run();
}

std::string stringify(const Value& value) {
    std::string out;
    out.reserve(256);
    stringify_into(out, value);
    return out;
}

} // namespace such::mcp::json
